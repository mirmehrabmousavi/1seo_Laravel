<?php $__env->startSection('content'); ?>
    <div class="col-md-12 col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">افزودن سایت</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" action="<?php echo e(route('addSite',['url'=>$url])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <input type="text" id="first-name-vertical" class="form-control" name="sites"
                                               placeholder="آدرس سایت را وارد کنید">
                                    </div>
                                    <button type="submit" class="btn btn-primary mr-1 mb-1 waves-effect waves-light">
                                        تایید
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row" id="table-striped">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">سایت ها</h4>
                </div>
                <div class="card-content">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td><?php echo e($site_fi->sites); ?></td>
                                <td><?php echo e($site_fi->created_at->diffForHumans()); ?></td>
                                <td><button type="button" class="btn bg-gradient-danger mr-1 mb-1 waves-effect waves-light" disabled>حذف</button></td>
                            </tr>
                            <?php $__currentLoopData = $sites_ex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->index+2); ?></th>
                                    <td><?php echo e($val->sites); ?></td>
                                    <td><?php echo e($val->created_at->diffForHumans()); ?></td>
                                    <td>
                                        

                                        <form action="<?php echo e(route('delSite',['url' => $url,'id' => $val->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn bg-gradient-danger mr-1 mb-1 waves-effect waves-light">حذف</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\seo\resources\views/add-site/addSite_view.blade.php ENDPATH**/ ?>