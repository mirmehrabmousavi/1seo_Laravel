<div class="modal fade text-left" id="inlineForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel33">مدیریت کلمات کلیدی</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('update.keyword',['url' => $url])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="modal-body">
                    <label>کلمات کلیدی</label>
                    <div class="form-group">
                        <textarea name="keyword_site" placeholder="کلمات کلیدی را وارد کنید" class="form-control" required><?php echo e($init_seo->keyword_site); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">ثبت</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\Installed\www\seo\resources\views/modal/keyword.blade.php ENDPATH**/ ?>