<?php $__env->startSection('content'); ?>

    <section id="basic-horizontal-layouts">
        <div class="row">
            <div class="col-md-9 col-9">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">اطلاعات زیر را تکمیل کنید</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <?php $__currentLoopData = $related_key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(route('update.init.seo.related',['url' => $url,'id' => $rk->id])); ?>"
                                      method="POST"
                                      class="form form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form-group row">
                                                    <div class="col-md-4">
                                                        <span>کلمات مرتبط سایت : <?php echo e($rk->keyword_id); ?></span>
                                                    </div>
                                                    <br>
                                                    <br>
                                                    <textarea name="related_site" data-length=200
                                                              class="form-control char-textarea" id="keyword"
                                                              rows="6" placeholder="هر کلمه در یک سطر"
                                                              required><?php $__currentLoopData = explode("\r",$rk->related_site); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($value); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>

                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <button type="submit"
                                                        class="btn btn-primary mr-1 mb-1 waves-effect waves-light">ثبت
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-3">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <ul>
                                            <?php $__currentLoopData = $related_key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($rk->keyword_id); ?>

                                                    <ul>
                                                        <?php $__currentLoopData = explode("\r\n",$rk->related_site); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($val); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="block-level-buttons">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                        <a href="<?php echo e(route('internal.seo.index',['url' => $url])); ?>"
                                           class="btn mb-1 btn-primary btn-lg btn-block waves-effect waves-light">تکمیل
                                            کردم</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function setTextarea(t) {
            var optionValue = t.value;
            <?php $__currentLoopData = explode("\r\n",$init_seo_key->keyword_site); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            if (optionValue === <?php echo e($val); ?>) {
                <?php echo e($res = \App\Models\RelatedKey::where('keyword_id',$val)->first()); ?>

                document.getElementById('keyword').innerHTML = <?php echo e($res); ?>;
            } else {
                document.getElementById('keyword').innerHTML = ' ';
            }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\seo\resources\views/init_seo/edit-related-init-seo.blade.php ENDPATH**/ ?>