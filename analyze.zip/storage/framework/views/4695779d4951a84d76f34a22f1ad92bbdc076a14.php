<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="
                <?php if(\Illuminate\Support\Str::contains(request()->url(),'addSite')): ?>
                                    سایت ها
                <?php elseif(\Illuminate\Support\Str::contains(request()->url(),'admin')): ?>
                                    پنل ادمین
                <?php else: ?><?php echo e(route('home',['url' => $url])); ?>

                <?php endif; ?>">
                    <img src="/app-assets/images/logo300.png" height="35" width="70">
                </a>
            </li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" navigation-header"><span>ورژن v1.0.2</span>
            </li>
            <li class="nav-item has-sub"><a href="<?php echo e(route('home',['url' => auth()->user()->url])); ?>"><i
                        class="feather icon-layout"></i><span class="menu-title"
                                                              data-i18n="Content">آنالیز</span></a>
                <ul class="menu-content" style="">
                    <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e(request()->input($site->sites) ? 'active' : ''); ?>"><a
                                href="<?php echo e(route('home',['url'=>$site->sites])); ?>"><i class="feather icon-circle"></i><span
                                    class="menu-item"
                                    data-i18n="Grid"><?php echo e($site->sites); ?></span></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class=""><a href="<?php echo e(route('addSiteView',['url'=>$url])); ?>"><i class="feather icon-plus"></i><span
                                class="menu-item"
                                data-i18n="Helper Classes">افزودن سایت</span></a></li>
                </ul>
            </li>

            <li class=" navigation-header"><span>مارکتینگ پلن</span>
            </li>
            <li class="nav-item"><a href="<?php echo e(route('marketing.plan',['url' => $url])); ?>"><i
                        class="feather icon-calendar"></i><span class="menu-title"
                                                                data-i18n="Calender">سئو تکنیکال</span></a>
            </li>
            <li class="nav-item"><a href="<?php echo e(route('internal.seo', ['url' => $url])); ?>"><i
                        class="feather icon-calendar"></i><span class="menu-title" data-i18n="Calender">سئو داخلی</span></a>
            </li>
            <li class="nav-item"><a
                    href="<?php echo e((\App\Models\InitSeo::all()->isEmpty()) ? route('internal.seo',['url' => $url]) : route('off.seo.index',['url' => $url])); ?>"><i
                        class="feather icon-calendar"></i><span class="menu-title" data-i18n="Calender">سئو خارجی</span></a>
            </li>
        </ul>
    </div>
</div>
<!-- END: Main Menu-->
<?php /**PATH D:\Installed\www\seo\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>