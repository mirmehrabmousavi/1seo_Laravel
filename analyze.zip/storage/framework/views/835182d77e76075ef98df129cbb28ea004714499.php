<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="alert-colors">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">
                            فعالیت های سئو خارجی
                        </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <p>
                                فعالیت های روزانه ات اینجا به نمایش گذاشته می شه :)
                            </p>
                            <?php $__currentLoopData = $off_seo_action; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($actions->done === '0'): ?>
                                    <div class="alert alert-light" role="alert">
                                        <h4 class="alert-heading"><span
                                                class="float-right"><?php echo e($actions->created_at->diffForHumans()); ?></span>فعالیت <?php echo e($actions->id); ?>

                                        </h4>
                                        <p class="mb-0"><?php echo $actions->action; ?></p>
                                        <div class="row">
                                            <div class="col-lg-1 col-md-12">
                                                <a href="http://1seo.site/mag/"
                                                   class="btn bg-gradient-primary mr-1 mb-1 waves-effect waves-light">
                                                    راهنما
                                                </a>
                                            </div>
                                            <div class="col-lg-9 col-md-12"></div>
                                            <div class="col-lg-2 col-md-12">
                                                <button type="button"
                                                        class="btn bg-gradient-success btn-block mr-1 mb-1 waves-effect waves-light mt-1"
                                                        id="confirm-color" data-toggle="modal" data-target="#form<?php echo e($actions->id); ?>">انجام دادم
                                                </button>
                                                <!-- Modal -->
                                                <div class="modal fade text-left" id="form<?php echo e($actions->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel33" style="display: none;" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title" id="myModalLabel33">آدرس فعالیتت رو وارد کن</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">×</span>
                                                                </button>
                                                            </div>
                                                            <form action="<?php echo e(route('off.seo.add.url',['url' => $url , 'id' => $actions->id])); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('patch'); ?>
                                                                <div class="modal-body">
                                                                    <label>url: <?php echo e($actions->baseurl .' - '. $actions->id); ?></label>
                                                                    <div class="form-group">
                                                                        <input type="text" name="url" placeholder="آدرس محتواتو وارد کن" class="form-control">
                                                                    </div>
                                                                    <button type="submit" class="btn btn-primary waves-effect waves-light">تایید</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php elseif($actions->done === '1'): ?>
                                    <div class="alert alert-dark" role="alert">
                                    <h4 class="alert-heading"><span
                                            class="float-right"><?php echo e($actions->created_at->diffForHumans()); ?></span>  فعالیت <?php echo e($actions->id); ?>

                                    </h4>
                                    <p class="mb-0"><?php echo $actions->action; ?></p>
                                    <div class="row">
                                        <div class="col-lg-1 col-md-12"></div>
                                        <div class="col-lg-9 col-md-12"></div>
                                        <div class="col-lg-2 col-md-12">
                                            <button type="button"
                                                    class="btn bg-gradient-success btn-block mr-1 mb-1 waves-effect waves-light mt-1" disabled>انجام شد
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($off_seo_action->links('pagination.paginate')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\seo\resources\views/off_seo/off-seo-index.blade.php ENDPATH**/ ?>