<?php $__env->startSection('content'); ?>
    <section id="basic-horizontal-layouts">
        <div class="row match-height">
            <div class="col-md-12 col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">اطلاعات زیر را تکمیل کنید</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form action="#" method="POST" class="form form-horizontal">
                                <?php echo csrf_field(); ?>
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="type">
                                                    نوع سایت
                                                </label>
                                                <select class="custom-select form-control" id="type" name="keyword_id" required>
                                                    <option value="">کلمه کلیدی اصلی را انتخاب کنید</option>
                                                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-12 mb-1">
                                                <fieldset>
                                                    <div class="input-group">
                                                        <input type="text" class="form-control" placeholder="Button on right" aria-describedby="button-addon2">
                                                    </div>
                                                </fieldset>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <button type="submit" class="btn btn-primary mr-1 mb-1 waves-effect waves-light">ثبت</button>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-12 mb-1">
                                                <ul>
                                                    <li>salam
                                                        <ul>
                                                            <li>khobi</li>
                                                        </ul>
                                                    </li>
                                                    <li>salam</li>
                                                    <li>salam</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="#" class="btn btn-success mr-1 mb-1 waves-effect waves-light">بعدی</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\seo\resources\views/init_seo/related-keyword-init-seo.blade.php ENDPATH**/ ?>