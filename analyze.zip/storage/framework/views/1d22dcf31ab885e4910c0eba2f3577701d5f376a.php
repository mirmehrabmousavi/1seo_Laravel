<?php $__env->startSection('content'); ?>
    <section id="basic-vertical-layouts">
        <div class="row match-height">
            <div class="col-md-12 col-12">
                <div class="card" style="height: 501.406px;">
                    <div class="card-header">
                        <h4 class="card-title">تنظیمات سایت</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-vertical" action="<?php echo e(route('settings.add',$settings)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="text" id="first-name-vertical" class="form-control" name="title" value="<?php echo e($settings->title); ?>" placeholder="عنوان سایت">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="text" id="email-id-vertical" class="form-control" name="meta_desc" value="<?php echo e($settings->meta_desc); ?>" placeholder="متا توضیحات">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="text" id="contact-info-vertical" class="form-control" name="meta_key" value="<?php echo e($settings->meta_key); ?>" placeholder="متا کلمات کلیدی">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary mr-1 mb-1 waves-effect waves-light">ثبت</button>
                                            <button type="reset" class="btn btn-outline-warning mr-1 mb-1 waves-effect waves-light">ریست</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-12">
                <div class="card" style="height: 501.406px;">
                    <div class="card-header">
                        <h4 class="card-title">تنظیمات ادمین</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.add',$user)); ?>" class="form form-vertical" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="text" id="first-name-vertical" class="form-control" name="name" value="<?php echo e($user->name); ?>" placeholder="نام">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="email" id="email-id-vertical" class="form-control" name="email" value="<?php echo e($user->email); ?>" placeholder="ایمیل">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="number" id="email-id-vertical" class="form-control" name="number" value="<?php echo e($user->number); ?>" placeholder="شماره تماس">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="text" id="email-id-vertical" class="form-control" name="url" value="<?php echo e($user->url); ?>" placeholder="آدرس سایت">
                                            </div>
                                        </div>
                                        <div class="divider">
                                            <div class="divider-text">تغییر رمز عبور</div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="password" id="password-vertical" class="form-control" name="password" placeholder="رمز عبور">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <input type="password" id="password-vertical" class="form-control" name="password_confirmation" placeholder="تایید رمز عبور">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary mr-1 mb-1 waves-effect waves-light">ثبت</button>
                                            <button type="reset" class="btn btn-outline-warning mr-1 mb-1 waves-effect waves-light">ریست</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed\www\seo\resources\views/admin/siteSettings.blade.php ENDPATH**/ ?>